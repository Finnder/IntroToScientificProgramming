
lines = ['Just nine lines of code', 'Did I forget my syntax', 'Compiler error']

for line in lines:
    print(line)




