
# Calculates X and Y
# Prints the sum, difference, product and quotient and modulus
def calc(x, y):
    print(f'{x} + {y} = {x + y}')
    print(f'{x} - {y} = {x - y}')
    print(f'{x} * {y} = {x * y}')
    print(f'{x} / {y} = {x/y}')
    print(f'{x} % {y} = {x%y}')

calc(10, 20)
