message = """
Hi, my name is Finn - I am taking this course because I personally like to program and have been for awhile now. I am a CS major mainly taking this course for fun and for a gen ed requirement. My hobbies are game development, playing video games , and working out.
"""

print(message)
