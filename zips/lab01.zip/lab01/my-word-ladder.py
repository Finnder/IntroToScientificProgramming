# Word Ladder
# By: Finnegan McGuire
# Status: Complete

word = 'win'
print(word)

word = 'wins'
print(word)

word = 'won'
print(word)

word = 'went' 
print(word)

word = 'want'
print(word)
